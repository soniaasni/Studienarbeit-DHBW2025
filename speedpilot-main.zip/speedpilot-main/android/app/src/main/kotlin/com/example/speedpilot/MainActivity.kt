package com.example.speedpilot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
